import os
import time
import numpy as np
import torch
from PIL import Image
import torchvision.transforms as transforms
import imageio
import cv2
from Networks.net import MODEL as net
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
device = torch.device('cuda:0')
use_gpu = torch.cuda.is_available()

# 模型初始化
model = net(in_channel=2)
model_path = "models/model_10.pth"

if use_gpu:
    model = model.to(device)
    model.load_state_dict(torch.load(model_path))
else:
    model.load_state_dict(torch.load(model_path, map_location='cpu'))

# 定义图像融合函数
def fusion():
    # MRI 和 SPECT 图像的路径
    path1 = './SPECT-MRI/MRI/40037.png'
    path2 = './SPECT-MRI/SPECT/40037.png'
    
    tic = time.time()
    
    # 加载 MRI（灰度）和 SPECT（RGB）图像
    img1 = Image.open(path1).convert('L')  # MRI
    img2 = Image.open(path2).convert('RGB')  # SPECT
    
    # 转换 SPECT 图像到 YUV 空间
    spect_img = np.array(img2)
    spect_yuv = cv2.cvtColor(spect_img, cv2.COLOR_RGB2YUV)
    Y, U, V = cv2.split(spect_yuv)
    
    # 将 MRI 和 SPECT 的 Y 通道转换为张量并合并
    tran = transforms.ToTensor()
    img1_tensor = tran(img1)
    Y_tensor = tran(Image.fromarray(Y))
    input_img = torch.cat((img1_tensor, Y_tensor), 0).unsqueeze(0)

    if use_gpu:
        input_img = input_img.to(device)

    # 使用模型进行融合
    model.eval()
    with torch.no_grad():
        out = model(input_img)

    # 将融合后的 Y 通道转回 numpy 数组
    fused_Y = np.squeeze(out.cpu().numpy()) * 255  # 反归一化至 [0, 255]
    fused_Y = fused_Y.astype(np.uint8)

    # 将融合后的 Y 通道与原 U 和 V 通道合并
    fused_yuv = cv2.merge((fused_Y, U, V))
    fused_rgb = cv2.cvtColor(fused_yuv, cv2.COLOR_YUV2RGB)

    # 保存融合后的 RGB 图像
    output_path = './fusion result/fused_40037.png'
    Image.fromarray(fused_rgb).save(output_path)
    print(f'Saved fused image to: {output_path}')
    
    toc = time.time()
    print('Fusion completed, time taken: {:.2f} seconds'.format(toc - tic))

# 执行融合
if __name__ == '__main__':
    fusion()