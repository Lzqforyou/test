
import torch
import torch.nn as nn

from torch.nn import functional as F
import numpy as np  

class Conv2d(nn.Conv2d):

    def __init__(self, in_channels, out_channels, kernel_size, stride=1,
                 padding=0, dilation=1, groups=1, bias=True):
        super(Conv2d, self).__init__(in_channels, out_channels, kernel_size, stride,
                 padding, dilation, groups, bias)

        if kernel_size == 1:
            self.ind = True # self.ind: 一个标记，用于检查核大小是否为 1。若核大小为 1，则设为 True，这可能意味着在使用 1x1 卷积核时不需要额外处理。
        else:
            self.ind = False            
            self.oc = out_channels
            self.ks = kernel_size

            ws = kernel_size
            self.avg_pool = nn.AdaptiveAvgPool2d((ws,ws)) # self.avg_pool: 自适应平均池化层，将输入大小调整为 (ws, ws)（与核大小相同）

            self.num_lat = int((kernel_size * kernel_size) / 2 + 1) # 基于核大小计算的潜在维度，取核元素的一半加一，可能用于压缩或降低特征维度。

            self.ce = nn.Linear(ws*ws, self.num_lat, False) # 一个线性层，将 ws*ws（展平的空间维度）映射到 self.num_lat。该层可能学习空间特征的压缩表示。           
            self.ce_bn = nn.BatchNorm1d(in_channels)
            self.ci_bn2 = nn.BatchNorm1d(in_channels)

            self.act = nn.ReLU(inplace=True)
            

            if in_channels // 16: # 设置分组大小。如果 in_channels 大于等于 16，则使用 16 作为分组大小，否则使用输入通道数。
                self.g = 16
            else:
                self.g = in_channels
            # 一个线性层，将分组大小（self.g）映射到 out_channels // (in_channels // self.g)。该层可能用于实现通道或分组之间的交互。
            self.ci = nn.Linear(self.g, out_channels // (in_channels // self.g), bias=False)
            self.ci_bn = nn.BatchNorm1d(out_channels)
            # self.gd 和 self.gd2: 线性层，将 self.num_lat 映射到 kernel_size * kernel_size。这些层可能用于根据输入特征图生成动态滤波器或权重，输出可以被重塑或解释为卷积核。
            self.gd = nn.Linear(self.num_lat, kernel_size * kernel_size, False)
            self.gd2 = nn.Linear(self.num_lat, kernel_size * kernel_size, False)
            # 一个 nn.Unfold 层，用于从批处理的输入张量中提取滑动局部块。这在为动态操作（例如动态滤波）准备图像块时非常有用。
            self.unfold = nn.Unfold(kernel_size, dilation, padding, stride)

            self.sig = nn.Sigmoid()
    def forward(self, x):

        if self.ind:
            return F.conv2d(x, self.weight, self.bias, self.stride,
                        self.padding, self.dilation, self.groups)
        else:
            b, c, h, w = x.size()
            weight = self.weight
            # self.avg_pool(x) 对输入 x 进行自适应平均池化，将其空间维度缩小到 (self.ks, self.ks)，其中 self.ks 是卷积核大小。
            # 将结果重塑为 gl，形状为 [batch_size, channels, kernel_size * kernel_size]，为后续的线性变换做准备。
            gl = self.avg_pool(x).view(b,c,-1)

            out = self.ce(gl) # 对 gl 进行线性变换，将展平的空间维度映射到一个较小的潜在维度（self.num_lat），结果存储在 out 中。

            ce2 = out
            out = self.ce_bn(out)
            out = self.act(out)

            out = self.gd(out) # 对 out 进行第二次线性变换，将潜在维度（self.num_lat）映射回 kernel_size * kernel_size。

            if self.g >3:

                oc = self.ci(self.act(self.ci_bn2(ce2).view(b, c//self.g, self.g, -1).transpose(2,3))).transpose(2,3).contiguous()
            else:

                oc = self.ci(self.act(self.ci_bn2(ce2).transpose(2,1))).transpose(2,1).contiguous() 
            oc = oc.view(b,self.oc,-1)  # oc 被重新调整形状，使其变为 [batch_size, out_channels, -1]。
            oc = self.ci_bn(oc)
            oc = self.act(oc)

            oc = self.gd2(oc)  # self.gd2(oc) 对 oc 进行线性变换，将其映射回 kernel_size * kernel_size 的空间，可能用于动态生成卷积核。
            # 将之前计算的 out 调整为 [batch_size, 1, channels, kernel_size, kernel_size] 的形状。
            # oc      被调整为       [batch_size, out_channels, 1, kernel_size, kernel_size] 的形状。
            # out + oc 相加后通过 self.sig（Sigmoid）激活，将输出限制在 0 到 1 的范围内，用于权重或滤波器的动态调整。
            out = self.sig(out.view(b, 1, c, self.ks, self.ks) + oc.view(b, self.oc, 1, self.ks, self.ks))
            # 使用 nn.Unfold 将输入 x 拆解为滑动的局部块。x_un 的形状为 [batch_size, channels * kernel_size * kernel_size, num_blocks]，其中 num_blocks 是提取的局部块数。
            x_un = self.unfold(x) 
            b, _, l = x_un.size()
            # weight.unsqueeze(0) 将卷积核的权重扩展一个维度，与 out 相乘，实现加权。out 被调整为 [batch_size, out_channels, -1]。
            out = (out * weight.unsqueeze(0)).view(b, self.oc, -1)
            # torch.matmul(out, x_un) 执行矩阵乘法，将加权后的输出与图像块相乘，实现类似卷积的操作。 将输出调整形状，恢复为 [batch_size, out_channels, height, width]
            return torch.matmul(out, x_un).view(b, self.oc, int(np.sqrt(l)), int(np.sqrt(l)))
            
